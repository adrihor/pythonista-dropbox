# -*- coding: utf-8 -*-

__author__ = 'Don M. Morehouse'
__email__ = 'dmmmdfll@gmail.com'
__version__ = '0.1.0'
