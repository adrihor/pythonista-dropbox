============
Installation
============

At the command line::

    $ easy_install hello_world

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv hello_world
    $ pip install hello_world
