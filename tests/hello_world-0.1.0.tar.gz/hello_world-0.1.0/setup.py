#!/usr/bin/env python
# -*- coding: utf-8 -*-


try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup


with open('README.rst') as readme_file:
    readme = readme_file.read()

with open('HISTORY.rst') as history_file:
    history = history_file.read().replace('.. :changelog:', '')

requirements = [
    # TODO: put package requirements here
]

test_requirements = [
    # TODO: put package test requirements here
]
format_kwargs = {
    'run_command': 'say-hello',
    'app_directory': 'hello_world.hello_world', 
}
entry_points = {
    'console_scripts': ['{run_command} = {app_directory}:main'.format(**format_kwargs)]
}
setup(
    name='hello_world',
    version='0.1.0',
    description="Spike to see how a Python package can be created.",
    long_description=readme + '\n\n' + history,
    author="Don M. Morehouse",
    author_email='dmmmdfll@gmail.com',
    url='https://github.com/dmorehousemd/hello_world',
    packages=[
        'hello_world',
    ],
    package_dir={'hello_world':
                 'hello_world'},
    include_package_data=True,
    install_requires=requirements,
    license="ISCL",
    zip_safe=False,
    keywords='hello_world',
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: ISC License (ISCL)',
        'Natural Language :: English',
        "Programming Language :: Python :: 2",
        'Programming Language :: Python :: 2.6',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
    ],
    test_suite='tests',
    tests_require=test_requirements,
    entry_points = entry_points
)
