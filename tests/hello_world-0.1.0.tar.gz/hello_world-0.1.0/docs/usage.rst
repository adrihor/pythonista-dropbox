========
Usage
========

To use Hello World in a project::

    import hello_world
