===============================
Hello World
===============================

.. image:: https://img.shields.io/travis/dmorehousemd/hello_world.svg
        :target: https://travis-ci.org/dmorehousemd/hello_world

.. image:: https://img.shields.io/pypi/v/hello_world.svg
        :target: https://pypi.python.org/pypi/hello_world


Spike to see how a Python package can be created.

* Free software: ISC license
* Documentation: https://hello_world.readthedocs.org.

Features
--------

* TODO
