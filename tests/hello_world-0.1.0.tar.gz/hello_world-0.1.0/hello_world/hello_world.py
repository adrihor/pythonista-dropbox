
# coding: utf-8

# In[ ]:

import requests


# In[ ]:

def get_ip():
    url = 'http://ipv4.icanhazip.com'
    response = requests.get(url)
    return ''.join(response.iter_content()).strip()


# In[ ]:

def main():
    print("Hello, world from the Python packaging spike.")
    print(get_ip())

